package com.mobile.application.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

//import com.mobile.application.model.HeadSet;
import com.mobile.application.model.Image;
import com.mobile.application.model.Item;
//import com.mobile.application.model.PowerBank;
//import com.mobile.application.repository.HeadSetRepository;
import com.mobile.application.repository.ItemRepository;


@Controller
//@RequestMapping("/accessories")

public class AccessoriesController {
	
	@Autowired
	private ItemRepository itemRepository ;

	 //to add the products
	@PostMapping("/saveaccess")
	public String saveaccess(Item item ) {
		
		itemRepository.save(item);
		return "accessories";
	}
	Image image;
	 @RequestMapping("/access")
		public String access()
		{
			return "/access";
		}
	    

	   
	    @RequestMapping("/addaccess")
		public String addaccess()
		{
			return "/addaccess";
		}
	//For power banks
	@PostMapping("/view-power")
	public ModelAndView power() {
	ModelAndView modelObject= new ModelAndView("accessview");
	try{
		List<Item> itemValue = (List <Item>) itemRepository.findAll();
		List<Item> item=new ArrayList<>();
		int productId = 17; 
		for (var iterate: itemValue)
		{ 
			if (iterate.getProductid()==(productId))
			{ 
				item.add(iterate);
			}
		}
		modelObject.addObject("list", item);
	} catch (Exception exception){
		 System.out.println(exception);
	 }
		return modelObject;
	}
	
	
    //For Head sets
	@PostMapping("/view-headset")
    public ModelAndView headset() {
		ModelAndView modelObject= new ModelAndView("accessview");
		try {
		List<Item> itemValue = (List <Item>) itemRepository.findAll();
		List<Item> item=new ArrayList<>();
		int productId = 18; 
		for (var iterate: itemValue)
		{
			if (iterate.getProductid()==(productId))
			{
				item.add(iterate);
			}
		}
		modelObject.addObject("list", item);
		}catch (Exception exception){
			 System.out.println(exception);
		 }return modelObject;
    }
      //For chargers
		@PostMapping("/view-charger")
		public ModelAndView charger() {
			ModelAndView modelObject= new ModelAndView("accessview");
			try {
			List<Item> itemValue = (List <Item>) itemRepository.findAll();
			List<Item> item=new ArrayList<>();
			int productID = 19; 
			for (var iterate: itemValue)
			{
				if (iterate.getProductid()==(productID))
				{
					item.add(iterate);
				}
			}
			modelObject.addObject("list", item);
			}catch (Exception exception){
				 System.out.println(exception);
			 }return modelObject;
		}
		
		//For mobile Covers

			@PostMapping("/view-cover")
			public ModelAndView cover() {
				ModelAndView modelObject= new ModelAndView("accessview");
				try {
				List<Item> itemValue = (List <Item>) itemRepository.findAll();
				List<Item> item=new ArrayList<>();
				int productId = 20; 
				for (var iterate: itemValue)
				{
					if (iterate.getProductid()==(productId))
					{
						item.add(iterate);
					}
				}
				modelObject.addObject("list", item);
				}
				catch (Exception exception){
					 System.out.println(exception);
				 }return modelObject;
			}
			
			//For Mobile Screen
			@PostMapping("/view-screen")
			public ModelAndView screen() {
				ModelAndView modelObject= new ModelAndView("accessview");
				try {
				List<Item> itemValue = (List <Item>) itemRepository.findAll();
				List<Item> item=new ArrayList<>();
				int productId = 21; 
				for (var iterate: itemValue)
				{
					if (iterate.getProductid()==(productId))
					{
						item.add(iterate);
					}
				}
				modelObject.addObject("list", item);
				}catch (Exception exception){
					 System.out.println(exception);
				 }return modelObject;
			}
		//For USB
			@PostMapping("/view-usb")
			public ModelAndView usb() {
				ModelAndView modelObject= new ModelAndView("accessview");
				try {
				List<Item> itemValue = (List <Item>) itemRepository.findAll();
				List<Item> item=new ArrayList<>();
				int productId = 22; 
				for (var iterate: itemValue)
				{
					if (iterate.getProductid()==(productId))
					{
						item.add(iterate);
					}
				}
				modelObject.addObject("list", item);
				}catch (Exception exception){
					 System.out.println(exception);
				 }return modelObject;
			}
//end of accessory
			
			
			//For Mobile Brands
			//For Apple phones
			@PostMapping("/apple")
		    public ModelAndView apple() {
				ModelAndView modelObject= new ModelAndView("accessview");
				try {
				List<Item> itemValue = (List <Item>) itemRepository.findAll();
				List<Item> item=new ArrayList<>();
				int productId = 11; 
				for (var iterate: itemValue)
				{
					if (iterate.getProductid()==(productId))
					{
						item.add(iterate);
					}
				}
				modelObject.addObject("list", item);
				}catch (Exception exception){
					 System.out.println(exception);
				 }return modelObject;
			}


			//for Vivo phones
			@PostMapping("/vivo")
			public ModelAndView vivo() {
				ModelAndView modelObject= new ModelAndView("accessview");
				try {
				List<Item> itemValue = (List <Item>) itemRepository.findAll();
				List<Item> item=new ArrayList<>();
				int productId = 15; 
				for (var iterate: itemValue)
				{
					if (iterate.getProductid()==(productId))
					{
						item.add(iterate);
					}
				}
				
				modelObject.addObject("list", item);
				}catch (Exception exception){
					 System.out.println(exception);
				 }return modelObject;
			}
			
			//for Real Me phones
			@PostMapping("/realme")
			
			public ModelAndView realme() {
				ModelAndView modelObject= new ModelAndView("accessview");
				try {
				List<Item> itemValue = (List <Item>) itemRepository.findAll();
				List<Item> item=new ArrayList<>();
				int productId = 16; 
				for (var iterate: itemValue)
				{
					if (iterate.getProductid()==(productId))
					{
						item.add(iterate);
					}
				}
				modelObject.addObject("list", item);
			}catch (Exception exception){
				 System.out.println(exception);
			 }return modelObject;
		    }
			
			//For one Plus
			@PostMapping("/oneplus")
			public ModelAndView oneplus() {
				ModelAndView modelObject= new ModelAndView("accessview");
				try {
				List<Item> itemValue = (List <Item>) itemRepository.findAll();
				List<Item> item=new ArrayList<>();
				int productId = 14; 
				for (var iterate: itemValue)
				{
					if (iterate.getProductid()==(productId))
					{
						item.add(iterate);
					}
				}
				modelObject.addObject("list", item);
				}catch (Exception exception){
					 System.out.println(exception);
				 }return modelObject;
		    }
			
			//For Samsung phones
			@PostMapping("/samsung")
			public ModelAndView samsung() {
				ModelAndView modelObject= new ModelAndView("accessview");
				try {
				List<Item> itemValue = (List <Item>) itemRepository.findAll();
				List<Item> item=new ArrayList<>();
				int productId = 12; 
				for (var iterate: itemValue)
				{
					if (iterate.getProductid()==(productId))
					{
						item.add(iterate);
					}
				}
				modelObject.addObject("list", item);
			}catch (Exception exception){
				 System.out.println(exception);
			 }return modelObject;
		    }
			
			//For MI phones
			@PostMapping("/mi")
			public ModelAndView mi() {
				ModelAndView modelObject= new ModelAndView("accessview");
				try {
				List<Item> itemValue = (List <Item>) itemRepository.findAll();
                List<Item> item=new ArrayList<>();
				int productId = 13; 
				for (var iterate: itemValue)
				{
					if (iterate.getProductid()==(productId))
					{
						item.add(iterate);
					}
				}
				modelObject.addObject("list", item);
			}catch (Exception exception){
				 System.out.println(exception);
			 }
				return modelObject;
		    }
			
			
			
			
			
			
			

}
