package com.mobile.application.model;

import java.util.ArrayList;
import java.util.List;

public class Image {
	public List<String> imageList(){
		List <String>img = new ArrayList<String>();
		img.add("BOAT");
		img.add("AMBRANE");
		img.add("REDMI_POWER_BANK");
		img.add("MI_POWER_BANK");
		img.add("JBL");
		img.add("SKUL_CANDY");
		img.add("ONEPLUS");
		img.add("BOAT_USB");
		img.add("ESR_SCREEN_PROTECTOR");
		img.add("HYBRID_BACK_COVER");
		img.add("MI_2A");
		img.add("ONEPLUS_COVER");
		img.add("OPENTECH_TEMPERED");
		img.add("QUANTUM");
		img.add("SAMSUNG_COVER");
		img.add("SANDISK");
		img.add("SPIGEN");
		img.add("ZINQQ");
		
		
		return img;
		
	}

}
